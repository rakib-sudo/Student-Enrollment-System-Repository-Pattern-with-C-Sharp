﻿using Repository_C_Sharp.Models;
using Repository_C_Sharp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_C_Sharp.DI
{
    internal class TestAll
    {
        public void DisplayOptions()
        {
            Console.WriteLine("1 Show All Student");
            Console.WriteLine("2 Insert Student");
            Console.WriteLine("3 Update Student");
            Console.WriteLine("4 Delete Student");
            var index = int.Parse(Console.ReadLine());
            Show(index);
        }
        public void Show(int index)
        {
            StudentRepository studentRepository = new StudentRepository();
            if (index == 1)
            {
                var studentList = studentRepository.GetAll();
                if (studentList.Count() == 0)
                {
                    Console.WriteLine("=============================================");
                    Console.WriteLine("No item found in the list");
                    Console.WriteLine("=============================================");
                    DisplayOptions();
                }
                else
                {
                    foreach (var item in studentRepository.GetAll())
                    {

                        Console.WriteLine($"Student Id :{item.StudentId}, Name :{item.StudentName}, Age :{item.StudentAge},Email:{item.StudentEmail},Phone:{item.StudentPhone},Address:{item.StudentAddress}");
                    }
                    Console.WriteLine("=============================================");
                    DisplayOptions();
                }
            }

            else if (index == 2)
            {
                Console.WriteLine("=====================================");
                Console.Write("Name :");
                string name = Console.ReadLine();

                Console.Write("Age :");
                int age = Convert.ToInt32(Console.ReadLine());

                Console.Write("Email :");
                string email = Console.ReadLine();

                Console.Write("Phone :");
                string phone = Console.ReadLine();

                Console.Write("Address :");
                string address = Console.ReadLine();

                int maxId = studentRepository.GetAll().Any() ? studentRepository.GetAll().Max(x => x.StudentId) : 0;

                Student student = new Student
                {
                    StudentId = maxId + 1,
                    StudentName = name,
                    StudentAge = age,
                    StudentEmail = email,
                    StudentPhone = phone,
                    StudentAddress = address
                };
                studentRepository.Insert(student);
                Console.WriteLine("Data Inserted successfully!!!");
                Console.WriteLine("=====================================");
                DisplayOptions();
            }


            else if (index == 3)
            {
                Console.WriteLine("=====================================");
                Console.Write("Entry client id no to update : ");
                int id = Convert.ToInt32(Console.ReadLine());
                var _student = studentRepository.GetById(id);
                if (_student == null)
                {
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Student id is invalid!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                    return;
                }
                else
                {
                    Console.WriteLine($"Update info for student id :{id}");
                    Console.WriteLine("=====================================");
                    Console.Write("Name :");
                    string name = Console.ReadLine();

                    Console.Write("Age :");
                    int age = Convert.ToInt32(Console.ReadLine());

                    Console.Write("Email :");
                    string email = Console.ReadLine();

                    Console.Write("Phone :");
                    string phone = Console.ReadLine();

                    Console.Write("Address :");
                    string address = Console.ReadLine();

                    Student student = new Student
                    {
                        StudentId = id,
                        StudentName = name,
                        StudentAge = age,
                        StudentEmail = email,
                        StudentPhone = phone,
                        StudentAddress = address
                    };
                    studentRepository.Update(student);
                    Console.WriteLine("Data Updated successfully!!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
            }

            else if (index == 4)
            {
                Console.WriteLine("=====================================");
                Console.Write("Entry student id no to delete : ");
                int id = Convert.ToInt32(Console.ReadLine());
                var _student = studentRepository.GetById(id);
                if (_student == null)
                {
                    Console.WriteLine("=====================================");
                    Console.WriteLine("Student id is invalid!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                    return;
                }
                else
                {
                    studentRepository.Delete(id);
                    Console.WriteLine("Data Deleted successfully!!!");
                    Console.WriteLine("=====================================");
                    DisplayOptions();
                }
            }

        }
    }
}
