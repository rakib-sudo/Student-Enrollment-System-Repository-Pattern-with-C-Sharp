﻿using Repository_C_Sharp.DI;
using Repository_C_Sharp.Models;
using Repository_C_Sharp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_C_Sharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TestAll t = new TestAll();
            t.DisplayOptions();
            Console.ReadKey();
        }
        
    }
}
