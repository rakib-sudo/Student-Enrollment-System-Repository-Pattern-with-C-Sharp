﻿using Repository_C_Sharp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_C_Sharp.Repository
{
    internal class StudentRepository : Istudent_Repo
    {
        public void Delete(int id)
        {
            Student student = StudentDB.studentList.FirstOrDefault(x => x.StudentId == id);
            StudentDB.studentList.Remove(student);
        }

        public IEnumerable<Student> GetAll()
        {
            return StudentDB.studentList;
        }

        public Student GetById(int id)
        {
            Student student = StudentDB.studentList.FirstOrDefault(x => x.StudentId == id);
            return student;
        }

        public void Insert(Student student)
        {
            StudentDB.studentList.Add(student);
        }

        public void Update(Student student)
        {
            Student _student = StudentDB.studentList.FirstOrDefault(x => x.StudentId == student.StudentId);
            if (student.StudentName != null)
            {
                _student.StudentName = student.StudentName;
            }
            if (student.StudentAge != 0)
            {
                _student.StudentAge = student.StudentAge;
            }
        }
    }
}
